package com.example.wgmanager;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

public class AnalyticsActivity extends AppCompatActivity {

    private Button btnExport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);

        btnExport = findViewById(R.id.btnExport);
        if (btnExport == null) {
            Toast.makeText(this, "Fehler: btnExport nicht im Layout gefunden", Toast.LENGTH_LONG).show();
            return;
        }

        btnExport.setOnClickListener(v -> exportPdfAndShare());
    }

    private void exportPdfAndShare() {
        User me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) {
            Toast.makeText(this, "Keine WG", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!me.isAdminLike()) {
            Toast.makeText(this, "Nur Admin kann exportieren", Toast.LENGTH_SHORT).show();
            return;
        }

        String weekKey = WeekUtils.getCurrentWeekKey();
        List<CleaningTask> tasks = FakeDataStore.getCleaningTasks(me.wgId, weekKey);
        List<Strike> strikes = FakeDataStore.getStrikes(me.wgId, weekKey);

        try {
            File pdfFile = createPdfReport(me, weekKey, tasks, strikes);
            shareFile(pdfFile);
        } catch (Exception e) {
            Toast.makeText(this, "PDF Fehler: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private File createPdfReport(User me, String weekKey, List<CleaningTask> tasks, List<Strike> strikes) throws Exception {
        PdfDocument doc = new PdfDocument();

        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // A4-ish
        PdfDocument.Page page = doc.startPage(pageInfo);

        Canvas c = page.getCanvas();
        Paint p = new Paint();
        p.setTextSize(18f);

        int x = 40;
        int y = 60;

        c.drawText("WG Weekly Report", x, y, p);
        y += 30;

        p.setTextSize(12f);
        c.drawText("WG: " + me.wgId, x, y, p); y += 18;
        c.drawText("Week: " + weekKey, x, y, p); y += 28;

        p.setTextSize(14f);
        c.drawText("Cleaning Tasks:", x, y, p);
        y += 20;

        p.setTextSize(12f);
        for (CleaningTask t : tasks) {
            String assigned = "Unassigned";
            if (t.assignedUserId != null) {
                User u = FakeDataStore.getUserById(t.assignedUserId);
                if (u != null) assigned = u.displayName;
            }
            String line = "- " + t.title + " | " + (t.done ? "DONE" : "OPEN") + " | " + assigned;
            c.drawText(line, x, y, p);
            y += 16;
            if (y > 780) break;
        }

        y += 18;
        p.setTextSize(14f);
        c.drawText("Strikes:", x, y, p);
        y += 20;

        p.setTextSize(12f);
        for (Strike s : strikes) {
            User u = FakeDataStore.getUserById(s.userId);
            String name = (u != null ? u.displayName : s.userId);
            c.drawText("- " + name + ": " + s.reason, x, y, p);
            y += 16;
            if (y > 780) break;
        }

        doc.finishPage(page);

        File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (dir == null) dir = getFilesDir();

        File out = new File(dir, "wg_weekly_report_" + weekKey + ".pdf");
        try (FileOutputStream fos = new FileOutputStream(out)) {
            doc.writeTo(fos);
        }
        doc.close();

        Toast.makeText(this, "PDF erstellt: " + out.getName(), Toast.LENGTH_SHORT).show();
        return out;
    }

    private void shareFile(File file) {
        Uri uri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".fileprovider",
                file
        );

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(share, "Report teilen"));
    }
}

