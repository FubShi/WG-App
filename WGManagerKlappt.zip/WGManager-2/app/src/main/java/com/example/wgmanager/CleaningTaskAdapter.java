package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CleaningTaskAdapter extends RecyclerView.Adapter<CleaningTaskAdapter.VH> {

    public interface Listener {
        void onToggleDone(CleaningTask task);
        void onDelete(CleaningTask task);
        void onStrike(CleaningTask task);
    }

    private final Listener listener;
    private final List<CleaningTask> tasks = new ArrayList<>();
    private List<User> members = new ArrayList<>();
    private User me;

    public CleaningTaskAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<CleaningTask> tasks, List<User> members, User me) {
        this.tasks.clear();
        this.tasks.addAll(tasks);
        this.members = members;
        this.me = me;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cleaning_task, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        CleaningTask t = tasks.get(position);

        h.tvTitle.setText(t.title);

        String assigned = "Unassigned";
        if (t.assignedUserId != null) {
            User u = FakeDataStore.getUserById(t.assignedUserId);
            if (u != null) assigned = u.displayName;
        }
        h.tvAssigned.setText("Assigned: " + assigned);

        h.cbDone.setChecked(t.done);
        h.cbDone.setOnClickListener(v -> listener.onToggleDone(t));

        boolean admin = (me != null && me.isAdminLike());
        h.btnDelete.setVisibility(admin ? View.VISIBLE : View.GONE);
        h.btnStrike.setVisibility(admin ? View.VISIBLE : View.GONE);

        h.btnDelete.setOnClickListener(v -> listener.onDelete(t));
        h.btnStrike.setOnClickListener(v -> listener.onStrike(t));
    }

    @Override
    public int getItemCount() { return tasks.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvAssigned;
        CheckBox cbDone;
        Button btnDelete, btnStrike;

        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTaskTitle);
            tvAssigned = itemView.findViewById(R.id.tvTaskAssigned);
            cbDone = itemView.findViewById(R.id.cbDone);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnStrike = itemView.findViewById(R.id.btnStrike);
        }
    }
}


