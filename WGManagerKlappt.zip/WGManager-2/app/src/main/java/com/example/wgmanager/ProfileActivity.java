package com.example.wgmanager;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private ImageView ivProfile;
    private ImageView ivQr;
    private TextView tvName;
    private TextView tvEmail;
    private TextView tvRole;
    private TextView tvWg;

    private EditText etStatus;
    private Button btnSaveStatus;
    private Button btnPickImage;

    private ActivityResultLauncher<String> pickImageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ivProfile = findViewById(R.id.ivProfile);
        ivQr = findViewById(R.id.ivQr);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvRole = findViewById(R.id.tvRole);
        tvWg = findViewById(R.id.tvWg);

        etStatus = findViewById(R.id.etStatus);
        btnSaveStatus = findViewById(R.id.btnSaveStatus);
        btnPickImage = findViewById(R.id.btnPickImage);

        User me = SessionManager.getCurrentUser();
        if (me == null) {
            finish();
            return;
        }

        tvName.setText(me.displayName);
        tvEmail.setText(me.email);
        tvRole.setText("Role: " + me.role);
        tvWg.setText(me.hasWg() ? "WG: " + me.wgId : "WG: none");

        etStatus.setText(me.status == null ? "" : me.status);

        if (me.photoUri != null) {
            ivProfile.setImageURI(Uri.parse(me.photoUri));
        }

        // QR: simple invite content
        if (me.hasWg()) {
            try {
                ivQr.setImageBitmap(QRUtils.makeQr("wgId=" + me.wgId, 500));
            } catch (Exception e) {
                Toast.makeText(this, "QR Fehler: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        FakeDataStore.updatePhotoUri(me.id, uri.toString());
                        me.photoUri = uri.toString();
                        ivProfile.setImageURI(uri);
                    }
                }
        );

        btnPickImage.setOnClickListener(v -> pickImageLauncher.launch("image/*"));

        btnSaveStatus.setOnClickListener(v -> {
            String status = etStatus.getText().toString().trim();
            FakeDataStore.updateStatus(me.id, status);
            me.status = status;
            Toast.makeText(this, "Status gespeichert", Toast.LENGTH_SHORT).show();
        });
    }
}


