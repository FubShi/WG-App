package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CleaningWeekActivity extends AppCompatActivity implements CleaningTaskAdapter.Listener {

    private TextView tvWeek;
    private Button btnPrev, btnNext, btnAddTask;
    private RecyclerView rv;

    private String weekKey;
    private User me;
    private CleaningTaskAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaning_week);

        tvWeek = findViewById(R.id.tvWeek);
        btnPrev = findViewById(R.id.btnPrevWeek);
        btnNext = findViewById(R.id.btnNextWeek);
        btnAddTask = findViewById(R.id.btnAddTask);
        rv = findViewById(R.id.rvTasks);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) { finish(); return; }

        weekKey = WeekUtils.getCurrentWeekKey();
        tvWeek.setText(weekKey);

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CleaningTaskAdapter(this);
        rv.setAdapter(adapter);

        btnPrev.setOnClickListener(v -> {
            weekKey = WeekUtils.addWeeks(weekKey, -1);
            tvWeek.setText(weekKey);
            reload();
        });

        btnNext.setOnClickListener(v -> {
            weekKey = WeekUtils.addWeeks(weekKey, +1);
            tvWeek.setText(weekKey);
            reload();
        });

        // Aufgabe hinzufügen (nur Admin)
        btnAddTask.setOnClickListener(v -> {
            if (!me.isAdminLike()) {
                Toast.makeText(this, "Nur Admin kann Aufgaben hinzufügen", Toast.LENGTH_SHORT).show();
                return;
            }
            openAddTaskDialog();
        });

        reload();
    }

    private void reload() {
        List<CleaningTask> tasks = FakeDataStore.getCleaningTasks(me.wgId, weekKey);
        List<User> members = FakeDataStore.getWgMembers(me.wgId);
        adapter.submit(tasks, members, me);
    }

    private void openAddTaskDialog() {
        List<User> members = FakeDataStore.getWgMembers(me.wgId);

        View dlg = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etTitle = dlg.findViewById(R.id.etTaskTitle);
        Spinner sp = dlg.findViewById(R.id.spAssignee);

        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item);
        aa.add("Unassigned");
        for (User u : members) aa.add(u.displayName);
        sp.setAdapter(aa);

        new AlertDialog.Builder(this)
                .setTitle("Aufgabe hinzufügen")
                .setView(dlg)
                .setPositiveButton("Speichern", (d, w) -> {
                    String title = etTitle.getText().toString().trim();
                    if (title.isEmpty()) title = "Neuer Task";

                    int idx = sp.getSelectedItemPosition();
                    String assignedUserId = null;
                    if (idx > 0 && idx - 1 < members.size()) assignedUserId = members.get(idx - 1).id;

                    FakeDataStore.addCleaningTask(me.wgId, weekKey, title, assignedUserId);
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    @Override
    public void onToggleDone(CleaningTask task) {
        FakeDataStore.toggleTaskDone(me.wgId, weekKey, task.id);
        reload();
    }

    @Override
    public void onDelete(CleaningTask task) {
        if (!me.isAdminLike()) return;
        FakeDataStore.deleteCleaningTask(me.wgId, weekKey, task.id);
        reload();
    }

    @Override
    public void onStrike(CleaningTask task) {
        if (!me.isAdminLike()) return;

        // Strike verteilen (wenn assigned, dann vorausgewählt)
        List<User> members = FakeDataStore.getWgMembers(me.wgId);
        View dlg = LayoutInflater.from(this).inflate(R.layout.dialog_add_strike, null);

        Spinner sp = dlg.findViewById(R.id.spMembers);
        EditText etReason = dlg.findViewById(R.id.etReason);

        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item);
        int pre = 0;
        for (int i = 0; i < members.size(); i++) {
            User u = members.get(i);
            aa.add(u.displayName);
            if (task.assignedUserId != null && task.assignedUserId.equals(u.id)) pre = i;
        }
        sp.setAdapter(aa);
        sp.setSelection(pre);

        etReason.setText("Task \"" + task.title + "\" nicht erledigt");

        new AlertDialog.Builder(this)
                .setTitle("Strike verteilen")
                .setView(dlg)
                .setPositiveButton("Hinzufügen", (d, w) -> {
                    int idx = sp.getSelectedItemPosition();
                    if (idx < 0 || idx >= members.size()) return;

                    String reason = etReason.getText().toString().trim();
                    if (reason.isEmpty()) reason = "No reason";

                    FakeDataStore.addStrike(me.wgId, weekKey, members.get(idx).id, reason);
                    Toast.makeText(this, "Strike gespeichert", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }
}

