package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvHeader;
    private TextView tvWgInfo;

    private Button btnCleaning;
    private Button btnWall;
    private Button btnAnalytics;
    private Button btnProfile;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvHeader = findViewById(R.id.tvHeader);
        tvWgInfo = findViewById(R.id.tvWgInfo);

        btnCleaning = findViewById(R.id.btnCleaning);
        btnWall = findViewById(R.id.btnWall);
        btnAnalytics = findViewById(R.id.btnAnalytics);
        btnProfile = findViewById(R.id.btnProfile);
        btnLogout = findViewById(R.id.btnLogout);

        User u = SessionManager.getCurrentUser();
        if (u == null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }


        tvHeader.setText("Hallo, " + u.displayName + " (" + u.role + ")");
        tvWgInfo.setText(u.hasWg() ? ("WG: " + u.wgId) : "Du bist in keiner WG – Features sind gesperrt.");

        boolean hasWg = u.hasWg();
        boolean isAdmin = u.isAdminLike();

        // Features: nur wenn WG vorhanden
        btnCleaning.setEnabled(hasWg);
        btnWall.setEnabled(hasWg);

        // Analytics: z.B. nur Admin (du kannst das ändern)
        btnAnalytics.setVisibility(isAdmin ? View.VISIBLE : View.GONE);

        btnCleaning.setOnClickListener(v -> {
            if (!hasWg) {
                Toast.makeText(this, "Erst einer WG beitreten", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, CleaningWeekActivity.class));
        });

        btnWall.setOnClickListener(v -> {
            if (!hasWg) {
                Toast.makeText(this, "Erst einer WG beitreten", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, WallOfShameActivity.class));
        });

        btnAnalytics.setOnClickListener(v -> startActivity(new Intent(this, AnalyticsActivity.class)));
        btnProfile.setOnClickListener(v -> startActivity(new Intent(this, ProfileActivity.class)));

        btnLogout.setOnClickListener(v -> {
            SessionManager.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}