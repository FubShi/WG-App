package com.example.wgmanager;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CrewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crew);

        ListView listView = findViewById(R.id.listViewCrew);

        ArrayAdapter<DataStore.User> adapter = new ArrayAdapter<DataStore.User>(this, android.R.layout.simple_list_item_2, android.R.id.text1, DataStore.crew) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                DataStore.User u = getItem(position);
                text1.setText(u.name);
                text2.setText(u.role.toString());

                // Admin Logic: Click to kick
                if (DataStore.currentUserRole == DataStore.Role.ADMIN || DataStore.currentUserRole == DataStore.Role.SUPER_ADMIN) {
                    view.setOnClickListener(v -> {
                        Toast.makeText(getContext(), "Admin: " + u.name + " kicked!", Toast.LENGTH_SHORT).show();
                        // In real app: DataStore.crew.remove(u); notifyDataSetChanged();
                    });
                }
                return view;
            }
        };

        listView.setAdapter(adapter);
    }
}