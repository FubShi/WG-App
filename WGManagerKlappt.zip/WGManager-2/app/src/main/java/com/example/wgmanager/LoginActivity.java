package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Login läuft über MainActivity (activity_main.xml)
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}

