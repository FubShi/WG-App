package com.example.wgmanager;

import android.graphics.Bitmap;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

public class QRUtils {
    public static Bitmap makeQr(String content, int size) throws Exception {
        BitMatrix bm = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, size, size);
        Bitmap img = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                img.setPixel(x, y, bm.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        return img;
    }
}

