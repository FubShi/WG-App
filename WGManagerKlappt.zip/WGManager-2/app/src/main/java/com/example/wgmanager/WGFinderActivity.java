package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WGFinderActivity extends AppCompatActivity {

    private Spinner spWgs;
    private Button btnRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_finder);

        User me = SessionManager.getCurrentUser();
        if (me == null) { finish(); return; }

        spWgs = findViewById(R.id.spWgs);
        btnRequest = findViewById(R.id.btnRequest);

        ArrayAdapter<String> aa = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                FakeDataStore.getAvailableWgs()
        );
        spWgs.setAdapter(aa);

        btnRequest.setOnClickListener(v -> {
            String wgId = (String) spWgs.getSelectedItem();
            if (wgId == null || wgId.trim().isEmpty()) return;

            // Anfrage senden (Demo: auto-join)
            FakeDataStore.sendWgRequestAndAutoJoin(me.id, wgId);

            Toast.makeText(this, "Anfrage gesendet (Demo: beigetreten).", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }
}


