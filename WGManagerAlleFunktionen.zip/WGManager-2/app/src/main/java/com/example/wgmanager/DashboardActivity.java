package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvHeader;
    private TextView tvWgInfo;

    private Button btnCleaning;
    private Button btnWall;
    private Button btnAnalytics;
    private Button btnProfile;
    private Button btnLogout;

    // Optional: Neue Buttons (nur wenn du sie im XML anlegst)
    private Button btnBlackboard; // Schwarzes Brett
    private Button btnShopping;   // Einkaufsliste
    private Button btnCrew;       // WG-Crew

    private User u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvHeader = findViewById(R.id.tvHeader);
        tvWgInfo = findViewById(R.id.tvWgInfo);

        btnCleaning = findViewById(R.id.btnCleaning);
        btnWall = findViewById(R.id.btnWall);
        btnAnalytics = findViewById(R.id.btnAnalytics);
        btnProfile = findViewById(R.id.btnProfile);
        btnLogout = findViewById(R.id.btnLogout);

        // Neue Buttons nur "safe" holen (damit es nicht crasht, wenn sie noch nicht im XML sind)
        btnBlackboard = findViewByIdSafe(R.id.btnBlackboard);
        btnShopping = findViewByIdSafe(R.id.btnShopping);
        btnCrew = findViewByIdSafe(R.id.btnCrew);

        u = SessionManager.getCurrentUser();
        if (u == null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        // SuperAdmin -> SystemPanel (wie Ablaufdiagramm)
        if (u.role == Role.SUPER_ADMIN) {
            startActivity(new Intent(this, SystemPanelActivity.class));
            finish();
            return;
        }

        // Keine WG -> WGFinder (wie Ablaufdiagramm)
        if (!u.hasWg()) {
            startActivity(new Intent(this, WGFinderActivity.class));
            finish();
            return;
        }

        boolean hasWg = u.hasWg();      // hier true (wegen redirect), aber lassen wir der Klarheit halber
        boolean isAdmin = u.isAdminLike();

        tvHeader.setText("Hallo, " + u.displayName + " (" + u.role + ")");
        tvWgInfo.setText("WG: " + u.wgId);

        // Sichtbarkeit/Enable (du kannst das später feinjustieren)
        btnCleaning.setEnabled(hasWg);
        btnWall.setEnabled(hasWg);

        // Analytics: du hattest Admin-only -> bleibt so
        btnAnalytics.setVisibility(isAdmin ? View.VISIBLE : View.GONE);

        // Optional: neue Buttons nur mit WG
        if (btnBlackboard != null) btnBlackboard.setEnabled(hasWg);
        if (btnShopping != null) btnShopping.setEnabled(hasWg);
        if (btnCrew != null) btnCrew.setEnabled(hasWg);

        // Klicks
        btnCleaning.setOnClickListener(v -> {
            if (!hasWg) {
                Toast.makeText(this, "Erst einer WG beitreten", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, CleaningWeekActivity.class));
        });

        btnWall.setOnClickListener(v -> {
            if (!hasWg) {
                Toast.makeText(this, "Erst einer WG beitreten", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, WallOfShameActivity.class));
        });

        btnAnalytics.setOnClickListener(v ->
                startActivity(new Intent(this, AnalyticsActivity.class))
        );

        btnProfile.setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class))
        );

        // Neue Module (nur wenn Buttons existieren)
        if (btnBlackboard != null) {
            btnBlackboard.setOnClickListener(v ->
                    startActivity(new Intent(this, ComplaintBoardActivity.class))
            );
        }

        if (btnShopping != null) {
            btnShopping.setOnClickListener(v -> {
                if (!hasWg) return;
                startActivity(new Intent(this, ShoppingListActivity.class));
            });
        }

        if (btnCrew != null) {
            btnCrew.setOnClickListener(v -> {
                if (!hasWg) return;
                startActivity(new Intent(this, WGCrewActivity.class));
            });
        }

        // Logout: sauber zurück zu MainActivity (Login)
        btnLogout.setOnClickListener(v -> {
            SessionManager.setCurrentUser(null); // oder SessionManager.logout(), falls vorhanden
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    // Helper: verhindert Crash, wenn Button-ID im Layout noch nicht existiert
    private <T extends View> T findViewByIdSafe(int id) {
        try {
            return findViewById(id);
        } catch (Exception e) {
            return null;
        }
    }
}
