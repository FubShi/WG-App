package com.example.wgmanager;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TicketActivity extends AppCompatActivity {

    private ArrayAdapter<DataStore.Ticket> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);

        ListView listView = findViewById(R.id.listViewTickets);
        EditText etTicket = findViewById(R.id.etTicket);
        CheckBox cbKudos = findViewById(R.id.cbKudos);
        Button btnAdd = findViewById(R.id.btnAddTicket);

        adapter = new ArrayAdapter<DataStore.Ticket>(this, android.R.layout.simple_list_item_2, android.R.id.text1, DataStore.tickets) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                DataStore.Ticket t = getItem(position);

                // Styling based on Type
                String prefix = t.type == DataStore.TicketType.KUDOS ? "❤️ " : "⚠️ ";
                text1.setText(prefix + t.text);
                text1.setTextColor(t.type == DataStore.TicketType.KUDOS ? 0xFFFBBF24 : 0xFFFFFFFF); // Gold or White

                text2.setText("By " + t.author + (t.isSolved ? " [SOLVED]" : ""));

                // Admin Logic: Click to Solve (only for complaints)
                if (DataStore.currentUserRole == DataStore.Role.ADMIN && t.type == DataStore.TicketType.COMPLAINT) {
                    view.setOnClickListener(v -> {
                        t.isSolved = true;
                        notifyDataSetChanged();
                        Toast.makeText(getContext(), "Marked as Solved", Toast.LENGTH_SHORT).show();
                    });
                }
                return view;
            }
        };
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            String text = etTicket.getText().toString();
            if (!text.isEmpty()) {
                DataStore.TicketType type = cbKudos.isChecked() ? DataStore.TicketType.KUDOS : DataStore.TicketType.COMPLAINT;
                DataStore.tickets.add(0, new DataStore.Ticket(text, DataStore.currentUserName, type));
                adapter.notifyDataSetChanged();
                etTicket.setText("");
                cbKudos.setChecked(false);
            }
        });
    }
}