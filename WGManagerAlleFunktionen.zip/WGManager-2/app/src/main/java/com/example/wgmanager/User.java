package com.example.wgmanager;

public class User {
    public String id;
    public String email;
    public String displayName;
    public Role role;
    public String wgId;          // null/"" => keine WG
    public String status;        // frei editierbar
    public String photoUri;      // String von content://...

    public User(String id, String email, String displayName, Role role, String wgId) {
        this.id = id;
        this.email = email;
        this.displayName = displayName;
        this.role = role;
        this.wgId = wgId;
        this.status = "";
        this.photoUri = null;
    }

    public boolean hasWg() {
        return wgId != null && !wgId.trim().isEmpty();
    }

    public boolean isAdminLike() {
        return role == Role.ADMIN || role == Role.SUPER_ADMIN;
    }
}
