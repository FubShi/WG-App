package com.example.wgmanager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class FakeDataStore {

    // Demo Logins:
    // admin@wg.de / 123456  -> ADMIN + WG
    // user@wg.de  / 123456  -> USER + WG
    // nowg@wg.de  / 123456  -> USER ohne WG (geht zum WGFinder)
    // root@wg.de  / 123456  -> SUPER_ADMIN (geht zum SystemPanel)

    private static final Map<String, String> passwordByEmail = new HashMap<>();
    private static final Map<String, User> userByEmail = new HashMap<>();
    private static final Map<String, User> userById = new HashMap<>();

    // WG-Members: wgId -> [userId...]
    static final Map<String, List<String>> wgMembers = new HashMap<>();

    // Cleaning tasks: wgId -> weekKey -> tasks
    private static final Map<String, Map<String, List<CleaningTask>>> cleaningTasks = new HashMap<>();

    // Strikes: wgId -> weekKey -> strikes
    private static final Map<String, Map<String, List<Strike>>> strikes = new HashMap<>();

    // Complaints: wgId -> complaints
    private static final Map<String, List<Complaint>> complaints = new HashMap<>();

    // Shopping: wgId -> items
    private static final Map<String, List<ShoppingItem>> shoppingItems = new HashMap<>();

    static {
        seed();
    }

    private static void seed() {
        String wg1 = "wg_123";
        String wg2 = "wg_999";

        // Users
        User admin = new User("u_admin", "admin@wg.de", "Admin Max", Role.ADMIN, wg1);
        User user = new User("u_user", "user@wg.de", "Anna", Role.USER, wg1);
        User noWg = new User("u_nowg", "nowg@wg.de", "Gast", Role.USER, "");
        User superAdmin = new User("u_root", "root@wg.de", "Root", Role.SUPER_ADMIN, "");

        addUser(admin, "123456");
        addUser(user, "123456");
        addUser(noWg, "123456");
        addUser(superAdmin, "123456");

        // WG members
        wgMembers.put(wg1, new ArrayList<String>());
        wgMembers.get(wg1).add(admin.id);
        wgMembers.get(wg1).add(user.id);

        // zweite WG existiert (für WGFinder)
        wgMembers.put(wg2, new ArrayList<String>());

        // week init
        String wk = WeekUtils.getCurrentWeekKey();
        ensureWeekExists(wg1, wk);
        ensureWeekExists(wg2, wk);

        // Default tasks wg_123
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t1", "Bad"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t2", "Küche"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t3", "Flur"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t4", "Müll rausbringen"));

        // assign example
        assignTask(wg1, wk, "t2", user.id);

        // strike example
        strikes.get(wg1).get(wk).add(new Strike("s1", user.id, "Küche nicht geputzt", wk));

        // init complaints/shopping
        complaints.put(wg1, new ArrayList<>());
        shoppingItems.put(wg1, new ArrayList<>());

        shoppingItems.get(wg1).add(new ShoppingItem("p1", wg1, "Milch"));
        shoppingItems.get(wg1).add(new ShoppingItem("p2", wg1, "Eier"));

        complaints.get(wg1).add(new Complaint("c1", wg1, user.id, "Bitte Mülltrennung beachten."));

        // wg2 init
        complaints.put(wg2, new ArrayList<>());
        shoppingItems.put(wg2, new ArrayList<>());
    }

    private static void addUser(User u, String password) {
        passwordByEmail.put(u.email, password);
        userByEmail.put(u.email, u);
        userById.put(u.id, u);
    }

    // ------------------ Auth ------------------
    public static User login(String email, String pwd) {
        if (email == null || pwd == null) return null;
        if (!passwordByEmail.containsKey(email)) return null;
        if (!passwordByEmail.get(email).equals(pwd)) return null;
        return userByEmail.get(email);
    }

    public static User getUserById(String id) {
        return userById.get(id);
    }

    // ------------------ WG Finder ------------------
    public static String[] getAvailableWgs() {
        return new String[]{"wg_123", "wg_999"};
    }

    // Demo: "Anfrage senden" = auto join
    public static void sendWgRequestAndAutoJoin(String userId, String wgId) {
        User u = userById.get(userId);
        if (u == null) return;
        if (wgId == null || wgId.trim().isEmpty()) return;

        u.wgId = wgId;

        if (!wgMembers.containsKey(wgId)) wgMembers.put(wgId, new ArrayList<>());
        if (!wgMembers.get(wgId).contains(userId)) wgMembers.get(wgId).add(userId);

        ensureWeekExists(wgId, WeekUtils.getCurrentWeekKey());
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
    }

    public static List<User> getWgMembers(String wgId) {
        List<User> res = new ArrayList<>();
        if (wgId == null || wgId.trim().isEmpty()) return res;

        List<String> ids = wgMembers.get(wgId);
        if (ids == null) return res;

        for (String uid : ids) {
            User u = userById.get(uid);
            if (u != null) res.add(u);
        }
        return res;
    }

    // Admin kick
    public static void kickMember(String wgId, String userId) {
        if (wgId == null || wgId.trim().isEmpty()) return;

        List<String> members = wgMembers.get(wgId);
        if (members != null) members.remove(userId);

        User u = userById.get(userId);
        if (u != null && wgId.equals(u.wgId)) {
            u.wgId = ""; // danach ohne WG
        }
    }

    // ------------------ Cleaning ------------------
    public static List<CleaningTask> getCleaningTasks(String wgId, String weekKey) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        return cleaningTasks.get(wgId).get(weekKey);
    }

    public static void addCleaningTask(String wgId, String weekKey, String title, String assignedUserId) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return;

        String id = UUID.randomUUID().toString();
        CleaningTask t = new CleaningTask(id, (title == null || title.trim().isEmpty()) ? "Neuer Task" : title.trim());
        t.assignedUserId = assignedUserId; // kann null sein
        cleaningTasks.get(wgId).get(weekKey).add(t);
    }

    public static void deleteCleaningTask(String wgId, String weekKey, String taskId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).id.equals(taskId)) {
                tasks.remove(i);
                return;
            }
        }
    }

    public static void assignTask(String wgId, String weekKey, String taskId, String userId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (CleaningTask t : tasks) {
            if (t.id.equals(taskId)) {
                t.assignedUserId = userId;
                return;
            }
        }
    }

    public static void toggleTaskDone(String wgId, String weekKey, String taskId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (CleaningTask t : tasks) {
            if (t.id.equals(taskId)) {
                t.done = !t.done;
                return;
            }
        }
    }

    // ------------------ Strikes / Wall of Shame ------------------
    public static List<Strike> getStrikes(String wgId, String weekKey) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        return strikes.get(wgId).get(weekKey);
    }

    public static void addStrike(String wgId, String weekKey, String userId, String reason) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return;

        String id = UUID.randomUUID().toString();
        String r = (reason == null || reason.trim().isEmpty()) ? "No reason" : reason.trim();
        strikes.get(wgId).get(weekKey).add(new Strike(id, userId, r, weekKey));
    }

    // ------------------ Complaints ------------------
    public static List<Complaint> getComplaints(String wgId) {
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        return complaints.get(wgId);
    }

    public static void addComplaint(String wgId, String authorUserId, String text) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        String id = UUID.randomUUID().toString();
        complaints.get(wgId).add(new Complaint(id, wgId, authorUserId, text));
    }

    public static void markComplaintSolved(String wgId, String complaintId) {
        List<Complaint> list = getComplaints(wgId);
        for (Complaint c : list) {
            if (c.id.equals(complaintId)) {
                c.solved = true;
                return;
            }
        }
    }

    // ------------------ Shopping ------------------
    public static List<ShoppingItem> getShoppingItems(String wgId) {
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
        return shoppingItems.get(wgId);
    }

    public static void addShoppingItem(String wgId, String name) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
        String id = UUID.randomUUID().toString();
        shoppingItems.get(wgId).add(new ShoppingItem(id, wgId, name));
    }

    public static void removeShoppingItem(String wgId, String itemId) {
        List<ShoppingItem> list = getShoppingItems(wgId);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(itemId)) {
                list.remove(i);
                return;
            }
        }
    }

    // ------------------ Profile ------------------
    public static void updateStatus(String userId, String status) {
        User u = userById.get(userId);
        if (u != null) u.status = (status == null ? "" : status);
    }

    public static void updatePhotoUri(String userId, String photoUri) {
        User u = userById.get(userId);
        if (u != null) u.photoUri = photoUri;
    }

    // ------------------ Internal helper ------------------
    private static void ensureWeekExists(String wgId, String weekKey) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (weekKey == null || weekKey.trim().isEmpty()) weekKey = WeekUtils.getCurrentWeekKey();

        if (!cleaningTasks.containsKey(wgId)) cleaningTasks.put(wgId, new HashMap<>());
        if (!strikes.containsKey(wgId)) strikes.put(wgId, new HashMap<>());

        if (!cleaningTasks.get(wgId).containsKey(weekKey)) {
            cleaningTasks.get(wgId).put(weekKey, new ArrayList<>());
        }
        if (!strikes.get(wgId).containsKey(weekKey)) {
            strikes.get(wgId).put(weekKey, new ArrayList<>());
        }
    }
}

