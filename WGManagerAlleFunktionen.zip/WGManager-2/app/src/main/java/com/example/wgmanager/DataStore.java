package com.example.wgmanager;

import java.util.ArrayList;
import java.util.List;

public class DataStore {

    // Roles
    public enum Role { USER, ADMIN, SUPER_ADMIN }
    public enum TicketType { COMPLAINT, KUDOS }

    // Current User State
    public static Role currentUserRole = Role.USER;
    public static String currentUserName = "";
    public static int currentUserPoints = 120; // Current User Score

    // Mock Credentials
    public static final String EMAIL_USER = "user@wg.com"; // Has WG
    public static final String EMAIL_ADMIN = "admin@wg.com"; // Has WG
    public static final String EMAIL_SUPER = "super@wg.com"; // SuperAdmin
    public static final String EMAIL_NEW = "new@wg.com"; // No WG
    public static final String PASS = "1234";

    // Data Models
    public static class Task {
        String title;
        String assignedTo;
        boolean isDone;
        public Task(String t, String a) { title = t; assignedTo = a; isDone = false; }
        public String toString() { return title + " (" + assignedTo + ")"; }
    }

    public static class Ticket {
        String text;
        String author;
        boolean isSolved;
        TicketType type;

        public Ticket(String t, String a, TicketType type) {
            text = t;
            author = a;
            this.type = type;
            isSolved = false;
        }
    }

    public static class User {
        String name;
        Role role;
        int points;

        public User(String n, Role r, int p) { name = n; role = r; points = p; }
        public String toString() { return name + " [" + points + " pts]"; }
    }

    public static class ShoppingItem {
        String name;
        double price;

        public ShoppingItem(String n, double p) { name = n; price = p; }
        public String toString() { return name + " (" + String.format("%.2f", price) + "€)"; }
    }

    // Lists
    public static List<ShoppingItem> shoppingList = new ArrayList<>();
    public static List<Task> cleaningTasks = new ArrayList<>();
    public static List<Ticket> tickets = new ArrayList<>();
    public static List<User> crew = new ArrayList<>();

    // Initialize Mock Data
    static {
        shoppingList.add(new ShoppingItem("Milk", 1.20));
        shoppingList.add(new ShoppingItem("Toilet Paper", 4.50));
        shoppingList.add(new ShoppingItem("Pasta", 0.99));

        cleaningTasks.add(new Task("Clean Kitchen", "Max"));
        cleaningTasks.add(new Task("Trash", "Anna"));

        tickets.add(new Ticket("Music too loud!", "Max", TicketType.COMPLAINT));
        tickets.add(new Ticket("Great Dinner!", "Anna", TicketType.KUDOS));

        crew.add(new User("Max", Role.USER, 120));
        crew.add(new User("Anna", Role.ADMIN, 95));
        crew.add(new User("Tom", Role.USER, 40));
    }
}