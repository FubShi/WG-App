package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ShoppingListActivity extends AppCompatActivity implements ShoppingAdapter.Listener {

    private RecyclerView rv;
    private Button btnAdd;

    private User me;
    private ShoppingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        rv = findViewById(R.id.rvShopping);
        btnAdd = findViewById(R.id.btnAddShopping);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) { finish(); return; } // nur WG User/Admin

        adapter = new ShoppingAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> openAddDialog());

        reload();
    }

    private void reload() {
        List<ShoppingItem> list = FakeDataStore.getShoppingItems(me.wgId);
        adapter.submit(list);
    }

    private void openAddDialog() {
        View dlg = LayoutInflater.from(this).inflate(R.layout.dialog_add_shopping, null);
        EditText et = dlg.findViewById(R.id.etShoppingName);

        new AlertDialog.Builder(this)
                .setTitle("Artikel hinzufügen")
                .setView(dlg)
                .setPositiveButton("Hinzufügen", (d, w) -> {
                    String name = et.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Bitte Artikel eingeben", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FakeDataStore.addShoppingItem(me.wgId, name);
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    @Override
    public void onRemove(ShoppingItem item) {
        FakeDataStore.removeShoppingItem(me.wgId, item.id);
        reload();
    }
}

