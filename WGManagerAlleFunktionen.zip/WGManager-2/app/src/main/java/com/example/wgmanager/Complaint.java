package com.example.wgmanager;

public class Complaint {
    public String id;
    public String wgId;
    public String authorUserId;
    public String text;
    public boolean solved;
    public long createdAt;

    public Complaint(String id, String wgId, String authorUserId, String text) {
        this.id = id;
        this.wgId = wgId;
        this.authorUserId = authorUserId;
        this.text = text;
        this.solved = false;
        this.createdAt = System.currentTimeMillis();
    }
}

