package com.example.wgmanager;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CleaningActivity extends AppCompatActivity {

    private ArrayAdapter<DataStore.Task> adapter;
    private EditText etNewTask;
    private Spinner spinnerAssignee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaning);

        ListView listView = findViewById(R.id.listViewCleaning);
        etNewTask = findViewById(R.id.etNewTask);
        spinnerAssignee = findViewById(R.id.spinnerAssignee);
        Button btnAdd = findViewById(R.id.btnAddTask);

        // Populate Spinner with Crew Members
        List<String> crewNames = new ArrayList<>();
        crewNames.add("Unassigned");
        for(DataStore.User u : DataStore.crew) {
            crewNames.add(u.name);
        }

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, crewNames);
        spinnerAssignee.setAdapter(spinnerAdapter);

        // Custom Adapter to handle Admin Buttons in the List
        adapter = new ArrayAdapter<DataStore.Task>(this, android.R.layout.simple_list_item_2, android.R.id.text1, DataStore.cleaningTasks) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                DataStore.Task task = getItem(position);
                text1.setText(task.title);
                text2.setText(task.assignedTo + (task.isDone ? " [DONE]" : " [OPEN]"));

                // On Click: Toggle Status
                view.setOnClickListener(v -> {
                    task.isDone = !task.isDone;
                    notifyDataSetChanged();
                });

                // ADMIN FEATURE: Long Press to punish/delete
                if (DataStore.currentUserRole == DataStore.Role.ADMIN || DataStore.currentUserRole == DataStore.Role.SUPER_ADMIN) {
                    view.setOnLongClickListener(v -> {
                        Toast.makeText(getContext(), "Admin Action: Strike Distributed!", Toast.LENGTH_SHORT).show();
                        return true;
                    });
                }
                return view;
            }
        };
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            String title = etNewTask.getText().toString();
            if (!title.isEmpty()) {
                String assignee = spinnerAssignee.getSelectedItem().toString();
                DataStore.cleaningTasks.add(new DataStore.Task(title, assignee));
                adapter.notifyDataSetChanged();
                etNewTask.setText("");
                spinnerAssignee.setSelection(0); // Reset to "Unassigned"
            }
        });
    }
}