package com.example.wgmanager;

public class Strike {
    public String id;
    public String userId;
    public String reason;
    public String weekKey;      // z.B. 2026-W05
    public long createdAt;

    public Strike(String id, String userId, String reason, String weekKey) {
        this.id = id;
        this.userId = userId;
        this.reason = reason;
        this.weekKey = weekKey;
        this.createdAt = System.currentTimeMillis();
    }
}