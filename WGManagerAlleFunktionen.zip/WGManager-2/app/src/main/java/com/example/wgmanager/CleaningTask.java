package com.example.wgmanager;

public class CleaningTask {
    public String id;
    public String title;
    public String assignedUserId;  // null => unassigned
    public boolean done;

    public CleaningTask(String id, String title) {
        this.id = id;
        this.title = title;
        this.assignedUserId = null;
        this.done = false;
    }
}