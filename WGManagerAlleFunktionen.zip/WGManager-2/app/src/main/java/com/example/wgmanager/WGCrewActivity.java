package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WGCrewActivity extends AppCompatActivity implements CrewAdapter.Listener {

    private RecyclerView rv;
    private CrewAdapter adapter;
    private User me;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_crew);

        rv = findViewById(R.id.rvCrew);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) { finish(); return; }

        adapter = new CrewAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        reload();
    }

    private void reload() {
        List<User> members = FakeDataStore.getWgMembers(me.wgId);
        adapter.submit(members, me);
    }

    @Override
    public void onKick(User user) {
        if (me == null || !me.isAdminLike()) return;

        new AlertDialog.Builder(this)
                .setTitle("Mitglied kicken?")
                .setMessage("Willst du " + user.displayName + " aus der WG entfernen?")
                .setPositiveButton("Ja, kicken", (d, w) -> {
                    FakeDataStore.kickMember(me.wgId, user.id);
                    Toast.makeText(this, "Mitglied entfernt", Toast.LENGTH_SHORT).show();
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }
}
