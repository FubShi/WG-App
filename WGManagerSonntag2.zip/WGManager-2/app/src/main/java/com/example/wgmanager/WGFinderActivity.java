package com.example.wgmanager;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WGFinderActivity extends AppCompatActivity implements WgFinderAdapter.Listener {

    private User me;
    private WgFinderAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_finder);

        me = SessionManager.getCurrentUser();
        if (me == null) { finish(); return; }

        RecyclerView rv = findViewById(R.id.rvWgFinder);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new WgFinderAdapter(this);
        rv.setAdapter(adapter);

        List<WgInfo> wgs = FakeDataStore.getAvailableWgs();
        adapter.submit(wgs);
    }

    @Override
    public void onRequestJoin(WgInfo wg) {
        boolean ok = FakeDataStore.createJoinRequest(wg.id, me.id);
        Toast.makeText(this,
                ok ? "Anfrage gesendet. Warte auf Admin-Bestätigung." : "Du hast bereits eine offene Anfrage oder bist schon Mitglied.",
                Toast.LENGTH_SHORT).show();
    }
}



