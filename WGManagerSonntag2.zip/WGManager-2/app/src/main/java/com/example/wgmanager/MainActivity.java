package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvError = findViewById(R.id.tvError);

        // Demo
        etEmail.setText("admin@wg.de");
        etPassword.setText("123456");

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            User u = FakeDataStore.login(email, pass);

            // Daten korrekt?
            if (u == null) {
                tvError.setVisibility(View.VISIBLE);
                tvError.setText("Fehlermeldung: Daten nicht korrekt.");
                return;
            }
            tvError.setVisibility(View.GONE);

            SessionManager.setCurrentUser(u);

            // Rolle prüfen?
            if (u.role == Role.SUPER_ADMIN) {
                startActivity(new Intent(this, SystemPanelActivity.class));
                finish();
                return;
            }

            // Hat WG?
            if (!u.hasWg()) {
                startActivity(new Intent(this, WGFinderActivity.class));
                finish();
                return;
            }

            // Dashboard
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        });
    }
}


