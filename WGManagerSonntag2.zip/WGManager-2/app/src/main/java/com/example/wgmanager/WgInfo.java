package com.example.wgmanager;

public class WgInfo {
    public String id;
    public String name;
    public String description;
    public String adminUserId;

    public WgInfo(String id, String name, String description, String adminUserId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.adminUserId = adminUserId;
    }
}
