package com.example.wgmanager;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class WGRequestsActivity extends AppCompatActivity implements JoinRequestAdapter.Listener {

    private User me;
    private JoinRequestAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_requests);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg() || !me.isAdminLike()) { finish(); return; }

        RecyclerView rv = findViewById(R.id.rvRequests);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new JoinRequestAdapter(this);
        rv.setAdapter(adapter);

        reload();
    }

    private void reload() {
        adapter.submit(FakeDataStore.getPendingRequests(me.wgId));
    }

    @Override
    public void onApprove(JoinRequest r) {
        FakeDataStore.approveRequest(me.wgId, r.id);
        Toast.makeText(this, "Anfrage angenommen", Toast.LENGTH_SHORT).show();
        reload();
    }

    @Override
    public void onReject(JoinRequest r) {
        FakeDataStore.rejectRequest(me.wgId, r.id);
        Toast.makeText(this, "Anfrage abgelehnt", Toast.LENGTH_SHORT).show();
        reload();
    }
}


