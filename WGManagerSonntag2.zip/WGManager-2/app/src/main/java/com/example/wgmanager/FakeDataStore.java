package com.example.wgmanager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class FakeDataStore {

    // Demo Logins:
    // admin@wg.de / 123456  -> ADMIN + WG
    // user@wg.de  / 123456  -> USER + WG
    // nowg@wg.de  / 123456  -> USER ohne WG
    // root@wg.de  / 123456  -> SUPER_ADMIN

    private static final Map<String, String> passwordByEmail = new HashMap<>();
    private static final Map<String, User> userByEmail = new HashMap<>();
    private static final Map<String, User> userById = new HashMap<>();

    // WG-Members: wgId -> [userId...]
    static final Map<String, List<String>> wgMembers = new HashMap<>();

    // WG Infos: wgId -> info
    private static final Map<String, WgInfo> wgInfoById = new HashMap<>();

    // Join Requests: wgId -> requests
    private static final Map<String, List<JoinRequest>> joinRequestsByWg = new HashMap<>();

    // Cleaning tasks: wgId -> weekKey -> tasks
    private static final Map<String, Map<String, List<CleaningTask>>> cleaningTasks = new HashMap<>();

    // Strikes: wgId -> weekKey -> strikes
    private static final Map<String, Map<String, List<Strike>>> strikes = new HashMap<>();

    // Complaints: wgId -> complaints
    private static final Map<String, List<Complaint>> complaints = new HashMap<>();

    // Shopping: wgId -> items
    private static final Map<String, List<ShoppingItem>> shoppingItems = new HashMap<>();

    static {
        seed();
    }

    private static void seed() {
        String wg1 = "wg_123";
        String wg2 = "wg_999";

        // Users
        User admin = new User("u_admin", "admin@wg.de", "Admin Max", Role.ADMIN, wg1);
        User user = new User("u_user", "user@wg.de", "Anna", Role.USER, wg1);
        User noWg = new User("u_nowg", "nowg@wg.de", "Gast", Role.USER, "");
        User superAdmin = new User("u_root", "root@wg.de", "Root", Role.SUPER_ADMIN, "");

        addUser(admin, "123456");
        addUser(user, "123456");
        addUser(noWg, "123456");
        addUser(superAdmin, "123456");

        // WG info
        wgInfoById.put(wg1, new WgInfo(wg1, "WG Sonnenallee", "Zentrale WG in Neukölln. Sauberkeit ist Pflicht 🙂", admin.id));
        wgInfoById.put(wg2, new WgInfo(wg2, "WG Prenzlberg", "Ruhige WG, Fokus auf Ordnung und Einkaufsplan.", admin.id)); // admin als Demo

        // WG members
        wgMembers.put(wg1, new ArrayList<String>());
        wgMembers.get(wg1).add(admin.id);
        wgMembers.get(wg1).add(user.id);

        wgMembers.put(wg2, new ArrayList<String>()); // leer

        // Join Requests init
        joinRequestsByWg.put(wg1, new ArrayList<>());
        joinRequestsByWg.put(wg2, new ArrayList<>());

        // week init
        String wk = WeekUtils.getCurrentWeekKey();
        ensureWeekExists(wg1, wk);
        ensureWeekExists(wg2, wk);

        // Default tasks wg_123
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t1", "Bad"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t2", "Küche"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t3", "Flur"));
        cleaningTasks.get(wg1).get(wk).add(new CleaningTask("t4", "Müll rausbringen"));
        assignTask(wg1, wk, "t2", user.id);

        // strike example
        strikes.get(wg1).get(wk).add(new Strike("s1", user.id, "Küche nicht geputzt", wk));

        // init complaints/shopping
        complaints.put(wg1, new ArrayList<>());
        shoppingItems.put(wg1, new ArrayList<>());
        complaints.put(wg2, new ArrayList<>());
        shoppingItems.put(wg2, new ArrayList<>());

        shoppingItems.get(wg1).add(new ShoppingItem("p1", wg1, "Milch"));
        shoppingItems.get(wg1).add(new ShoppingItem("p2", wg1, "Eier"));
        complaints.get(wg1).add(new Complaint("c1", wg1, user.id, "Bitte Mülltrennung beachten."));
    }

    private static void addUser(User u, String password) {
        passwordByEmail.put(u.email, password);
        userByEmail.put(u.email, u);
        userById.put(u.id, u);
    }

    // ------------------ Auth ------------------
    public static User login(String email, String pwd) {
        if (email == null || pwd == null) return null;
        if (!passwordByEmail.containsKey(email)) return null;
        if (!passwordByEmail.get(email).equals(pwd)) return null;
        return userByEmail.get(email);
    }

    public static User getUserById(String id) {
        return userById.get(id);
    }

    // ------------------ WG Finder / WG Infos ------------------
    public static List<WgInfo> getAvailableWgs() {
        return new ArrayList<>(wgInfoById.values());
    }

    public static WgInfo getWgInfo(String wgId) {
        return wgInfoById.get(wgId);
    }

    public static int getMemberCount(String wgId) {
        List<String> m = wgMembers.get(wgId);
        return m == null ? 0 : m.size();
    }

    // ------------------ Join Requests ------------------
    public static boolean createJoinRequest(String wgId, String requesterUserId) {
        if (wgId == null || wgId.trim().isEmpty()) return false;
        if (requesterUserId == null || requesterUserId.trim().isEmpty()) return false;

        if (!joinRequestsByWg.containsKey(wgId)) joinRequestsByWg.put(wgId, new ArrayList<>());

        // schon member?
        List<String> members = wgMembers.get(wgId);
        if (members != null && members.contains(requesterUserId)) return false;

        // schon pending request?
        for (JoinRequest r : joinRequestsByWg.get(wgId)) {
            if (r.requesterUserId.equals(requesterUserId) && "PENDING".equals(r.status)) return false;
        }

        joinRequestsByWg.get(wgId).add(new JoinRequest(UUID.randomUUID().toString(), wgId, requesterUserId));
        return true;
    }

    // Admin: alle pending requests der eigenen WG
    public static List<JoinRequest> getPendingRequests(String wgId) {
        List<JoinRequest> res = new ArrayList<>();
        List<JoinRequest> list = joinRequestsByWg.get(wgId);
        if (list == null) return res;

        for (JoinRequest r : list) {
            if ("PENDING".equals(r.status)) res.add(r);
        }
        return res;
    }

    public static boolean approveRequest(String wgId, String requestId) {
        List<JoinRequest> list = joinRequestsByWg.get(wgId);
        if (list == null) return false;

        for (JoinRequest r : list) {
            if (r.id.equals(requestId) && "PENDING".equals(r.status)) {
                r.status = "APPROVED";
                addMemberToWg(wgId, r.requesterUserId);
                return true;
            }
        }
        return false;
    }

    public static boolean rejectRequest(String wgId, String requestId) {
        List<JoinRequest> list = joinRequestsByWg.get(wgId);
        if (list == null) return false;

        for (JoinRequest r : list) {
            if (r.id.equals(requestId) && "PENDING".equals(r.status)) {
                r.status = "REJECTED";
                return true;
            }
        }
        return false;
    }

    private static void addMemberToWg(String wgId, String userId) {
        if (!wgMembers.containsKey(wgId)) wgMembers.put(wgId, new ArrayList<>());
        if (!wgMembers.get(wgId).contains(userId)) wgMembers.get(wgId).add(userId);

        User u = userById.get(userId);
        if (u != null) u.wgId = wgId;

        ensureWeekExists(wgId, WeekUtils.getCurrentWeekKey());
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
    }

    public static List<User> getWgMembers(String wgId) {
        List<User> res = new ArrayList<>();
        if (wgId == null || wgId.trim().isEmpty()) return res;

        List<String> ids = wgMembers.get(wgId);
        if (ids == null) return res;

        for (String uid : ids) {
            User u = userById.get(uid);
            if (u != null) res.add(u);
        }
        return res;
    }

    // Admin kick
    public static void kickMember(String wgId, String userId) {
        if (wgId == null || wgId.trim().isEmpty()) return;

        List<String> members = wgMembers.get(wgId);
        if (members != null) members.remove(userId);

        User u = userById.get(userId);
        if (u != null && wgId.equals(u.wgId)) u.wgId = "";
    }

    // ------------------ Cleaning ------------------
    public static List<CleaningTask> getCleaningTasks(String wgId, String weekKey) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        return cleaningTasks.get(wgId).get(weekKey);
    }

    public static void addCleaningTask(String wgId, String weekKey, String title, String assignedUserId) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return;

        String id = UUID.randomUUID().toString();
        CleaningTask t = new CleaningTask(id, (title == null || title.trim().isEmpty()) ? "Neuer Task" : title.trim());
        t.assignedUserId = assignedUserId;
        cleaningTasks.get(wgId).get(weekKey).add(t);
    }

    public static void deleteCleaningTask(String wgId, String weekKey, String taskId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).id.equals(taskId)) {
                tasks.remove(i);
                return;
            }
        }
    }

    public static void assignTask(String wgId, String weekKey, String taskId, String userId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (CleaningTask t : tasks) {
            if (t.id.equals(taskId)) {
                t.assignedUserId = userId;
                return;
            }
        }
    }

    public static void toggleTaskDone(String wgId, String weekKey, String taskId) {
        List<CleaningTask> tasks = getCleaningTasks(wgId, weekKey);
        for (CleaningTask t : tasks) {
            if (t.id.equals(taskId)) {
                t.done = !t.done;
                return;
            }
        }
    }

    // ------------------ Strikes ------------------
    public static List<Strike> getStrikes(String wgId, String weekKey) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        return strikes.get(wgId).get(weekKey);
    }

    public static void addStrike(String wgId, String weekKey, String userId, String reason) {
        ensureWeekExists(wgId, weekKey);
        if (wgId == null || wgId.trim().isEmpty()) return;

        String id = UUID.randomUUID().toString();
        String r = (reason == null || reason.trim().isEmpty()) ? "No reason" : reason.trim();
        strikes.get(wgId).get(weekKey).add(new Strike(id, userId, r, weekKey));
    }

    // ------------------ Complaints ------------------
    public static List<Complaint> getComplaints(String wgId) {
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        return complaints.get(wgId);
    }

    public static void addComplaint(String wgId, String authorUserId, String text) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (!complaints.containsKey(wgId)) complaints.put(wgId, new ArrayList<>());
        String id = UUID.randomUUID().toString();
        complaints.get(wgId).add(new Complaint(id, wgId, authorUserId, text));
    }

    public static void markComplaintSolved(String wgId, String complaintId) {
        List<Complaint> list = getComplaints(wgId);
        for (Complaint c : list) {
            if (c.id.equals(complaintId)) {
                c.solved = true;
                return;
            }
        }
    }

    // ------------------ Shopping ------------------
    public static List<ShoppingItem> getShoppingItems(String wgId) {
        if (wgId == null || wgId.trim().isEmpty()) return new ArrayList<>();
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
        return shoppingItems.get(wgId);
    }

    public static void addShoppingItem(String wgId, String name) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (!shoppingItems.containsKey(wgId)) shoppingItems.put(wgId, new ArrayList<>());
        String id = UUID.randomUUID().toString();
        shoppingItems.get(wgId).add(new ShoppingItem(id, wgId, name));
    }

    public static void removeShoppingItem(String wgId, String itemId) {
        List<ShoppingItem> list = getShoppingItems(wgId);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(itemId)) {
                list.remove(i);
                return;
            }
        }
    }

    // ------------------ Profile ------------------
    public static void updateStatus(String userId, String status) {
        User u = userById.get(userId);
        if (u != null) u.status = (status == null ? "" : status);
    }

    public static void updatePhotoUri(String userId, String photoUri) {
        User u = userById.get(userId);
        if (u != null) u.photoUri = photoUri;
    }

    // ------------------ Internal helper ------------------
    private static void ensureWeekExists(String wgId, String weekKey) {
        if (wgId == null || wgId.trim().isEmpty()) return;
        if (weekKey == null || weekKey.trim().isEmpty()) weekKey = WeekUtils.getCurrentWeekKey();

        if (!cleaningTasks.containsKey(wgId)) cleaningTasks.put(wgId, new HashMap<>());
        if (!strikes.containsKey(wgId)) strikes.put(wgId, new HashMap<>());

        if (!cleaningTasks.get(wgId).containsKey(weekKey)) {
            cleaningTasks.get(wgId).put(weekKey, new ArrayList<>());
        }
        if (!strikes.get(wgId).containsKey(weekKey)) {
            strikes.get(wgId).put(weekKey, new ArrayList<>());
        }
    }
}


