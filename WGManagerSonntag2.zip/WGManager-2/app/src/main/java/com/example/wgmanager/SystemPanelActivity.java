package com.example.wgmanager;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SystemPanelActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system_panel);

        TextView tv = findViewById(R.id.tvSysInfo);
        User me = SessionManager.getCurrentUser();

        tv.setText("System Panel (SuperAdmin)\n\nUser: " +
                (me != null ? me.displayName + " / " + me.email : "none") +
                "\n\nHier kommen später: Userverwaltung, WGs verwalten, Rollen setzen.");
    }
}
