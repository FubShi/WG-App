package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ComplaintBoardActivity extends AppCompatActivity implements ComplaintAdapter.Listener {

    private RecyclerView rv;
    private Button btnAdd;

    private User me;
    private ComplaintAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_board);

        rv = findViewById(R.id.rvComplaints);
        btnAdd = findViewById(R.id.btnAddComplaint);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) { finish(); return; }

        adapter = new ComplaintAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> openAddDialog());

        reload();
    }

    private void reload() {
        List<Complaint> list = FakeDataStore.getComplaints(me.wgId);
        adapter.submit(list, me);
    }

    private void openAddDialog() {
        View dlg = LayoutInflater.from(this).inflate(R.layout.dialog_add_complaint, null);
        EditText et = dlg.findViewById(R.id.etComplaint);

        new AlertDialog.Builder(this)
                .setTitle("Beschwerde einreichen")
                .setView(dlg)
                .setPositiveButton("Senden", (d, w) -> {
                    String text = et.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "Bitte Text eingeben", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FakeDataStore.addComplaint(me.wgId, me.id, text);
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    @Override
    public void onMarkSolved(Complaint c) {
        if (me == null || !me.isAdminLike()) return;
        FakeDataStore.markComplaintSolved(me.wgId, c.id);
        reload();
    }
}
