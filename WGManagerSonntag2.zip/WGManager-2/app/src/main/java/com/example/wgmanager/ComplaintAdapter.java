package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ComplaintAdapter extends RecyclerView.Adapter<ComplaintAdapter.VH> {

    public interface Listener {
        void onMarkSolved(Complaint c);
    }

    private final Listener listener;
    private final List<Complaint> items = new ArrayList<>();
    private User me;

    public ComplaintAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Complaint> list, User me) {
        items.clear();
        items.addAll(list);
        this.me = me;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_complaint, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Complaint c = items.get(position);
        User author = FakeDataStore.getUserById(c.authorUserId);

        h.tvAuthor.setText(author != null ? author.displayName : c.authorUserId);
        h.tvText.setText(c.text);
        h.tvTime.setText(DateFormat.getDateTimeInstance().format(new Date(c.createdAt)));
        h.tvStatus.setText(c.solved ? "Status: GELÖST" : "Status: OFFEN");

        boolean canSolve = me != null && me.isAdminLike() && !c.solved;
        h.btnSolved.setVisibility(canSolve ? View.VISIBLE : View.GONE);
        h.btnSolved.setOnClickListener(v -> listener.onMarkSolved(c));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvAuthor, tvText, tvTime, tvStatus;
        Button btnSolved;

        VH(@NonNull View itemView) {
            super(itemView);
            tvAuthor = itemView.findViewById(R.id.tvComplaintAuthor);
            tvText = itemView.findViewById(R.id.tvComplaintText);
            tvTime = itemView.findViewById(R.id.tvComplaintTime);
            tvStatus = itemView.findViewById(R.id.tvComplaintStatus);
            btnSolved = itemView.findViewById(R.id.btnMarkSolved);
        }
    }
}
