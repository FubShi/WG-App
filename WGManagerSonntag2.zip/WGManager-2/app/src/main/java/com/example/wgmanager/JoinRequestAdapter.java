package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class JoinRequestAdapter extends RecyclerView.Adapter<JoinRequestAdapter.VH> {

    public interface Listener {
        void onApprove(JoinRequest r);
        void onReject(JoinRequest r);
    }

    private final Listener listener;
    private final List<JoinRequest> items = new ArrayList<>();

    public JoinRequestAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<JoinRequest> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_join_request, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        JoinRequest r = items.get(position);
        User requester = FakeDataStore.getUserById(r.requesterUserId);

        h.tvName.setText(requester != null ? requester.displayName : r.requesterUserId);
        h.tvMail.setText(requester != null ? requester.email : "-");
        h.btnApprove.setOnClickListener(v -> listener.onApprove(r));
        h.btnReject.setOnClickListener(v -> listener.onReject(r));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvMail;
        Button btnApprove, btnReject;

        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvReqName);
            tvMail = itemView.findViewById(R.id.tvReqMail);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnReject = itemView.findViewById(R.id.btnReject);
        }
    }
}


