package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WallOfShameActivity extends AppCompatActivity {

    private TextView tvWeek;
    private Button btnPrev, btnNext, btnAddStrike;
    private RecyclerView rv;

    private String weekKey;
    private User me;
    private StrikeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wall_of_shame);

        tvWeek = findViewById(R.id.tvWeek);
        btnPrev = findViewById(R.id.btnPrevWeek);
        btnNext = findViewById(R.id.btnNextWeek);
        btnAddStrike = findViewById(R.id.btnAddStrike);
        rv = findViewById(R.id.rvStrikes);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) {
            finish();
            return;
        }

        weekKey = WeekUtils.getCurrentWeekKey();
        tvWeek.setText(weekKey);

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new StrikeAdapter();
        rv.setAdapter(adapter);

        btnPrev.setOnClickListener(v -> {
            weekKey = WeekUtils.addWeeks(weekKey, -1);
            tvWeek.setText(weekKey);
            reload();
        });

        btnNext.setOnClickListener(v -> {
            weekKey = WeekUtils.addWeeks(weekKey, +1);
            tvWeek.setText(weekKey);
            reload();
        });

        btnAddStrike.setVisibility(me.isAdminLike() ? View.VISIBLE : View.GONE);
        btnAddStrike.setOnClickListener(v -> openAddStrikeDialog());

        reload();
    }

    private void reload() {
        List<Strike> list = FakeDataStore.getStrikes(me.wgId, weekKey);
        adapter.submit(list);
    }

    private void openAddStrikeDialog() {
        if (!me.isAdminLike()) {
            Toast.makeText(this, "Nur Admin", Toast.LENGTH_SHORT).show();
            return;
        }

        List<User> members = FakeDataStore.getWgMembers(me.wgId);
        View dlg = LayoutInflater.from(this).inflate(R.layout.dialog_add_strike, null);

        Spinner sp = dlg.findViewById(R.id.spMembers);
        EditText etReason = dlg.findViewById(R.id.etReason);
        etReason.setInputType(InputType.TYPE_CLASS_TEXT);

        ArrayAdapter<String> aa = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item
        );
        for (User u : members) {
            aa.add(u.displayName + " (" + u.email + ")");
        }
        sp.setAdapter(aa);

        new AlertDialog.Builder(this)
                .setTitle("Strike hinzufügen")
                .setView(dlg)
                .setPositiveButton("Hinzufügen", (d, w) -> {
                    int idx = sp.getSelectedItemPosition();
                    if (idx < 0 || idx >= members.size()) return;

                    String reason = etReason.getText().toString().trim();
                    if (reason.isEmpty()) reason = "No reason";

                    FakeDataStore.addStrike(me.wgId, weekKey, members.get(idx).id, reason);
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }
}
