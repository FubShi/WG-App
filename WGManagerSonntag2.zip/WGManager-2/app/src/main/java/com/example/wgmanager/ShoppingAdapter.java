package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingAdapter extends RecyclerView.Adapter<ShoppingAdapter.VH> {

    public interface Listener {
        void onRemove(ShoppingItem item);
    }

    private final Listener listener;
    private final List<ShoppingItem> items = new ArrayList<>();

    public ShoppingAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<ShoppingItem> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_shopping, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ShoppingItem it = items.get(position);
        h.tvName.setText(it.name);
        h.btnRemove.setOnClickListener(v -> listener.onRemove(it));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName;
        Button btnRemove;

        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvShoppingName);
            btnRemove = itemView.findViewById(R.id.btnRemoveShopping);
        }
    }
}

