package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CrewAdapter extends RecyclerView.Adapter<CrewAdapter.VH> {

    public interface Listener {
        void onKick(User user);
    }

    private final Listener listener;
    private final List<User> members = new ArrayList<>();
    private User me;

    public CrewAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<User> members, User me) {
        this.members.clear();
        this.members.addAll(members);
        this.me = me;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_crew_member, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        User u = members.get(position);
        h.tvName.setText(u.displayName);
        h.tvMail.setText(u.email);

        boolean admin = me != null && me.isAdminLike();
        boolean canKick = admin && me != null && !me.id.equals(u.id); // Admin kann sich selbst nicht kicken

        h.btnKick.setVisibility(canKick ? View.VISIBLE : View.GONE);
        h.btnKick.setOnClickListener(v -> listener.onKick(u));
    }

    @Override
    public int getItemCount() { return members.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvMail;
        Button btnKick;

        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvCrewName);
            tvMail = itemView.findViewById(R.id.tvCrewMail);
            btnKick = itemView.findViewById(R.id.btnKick);
        }
    }
}

