package com.example.wgmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WgFinderAdapter extends RecyclerView.Adapter<WgFinderAdapter.VH> {

    public interface Listener {
        void onRequestJoin(WgInfo wg);
    }

    private final Listener listener;
    private final List<WgInfo> items = new ArrayList<>();

    public WgFinderAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<WgInfo> wgs) {
        items.clear();
        items.addAll(wgs);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wg_finder, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        WgInfo wg = items.get(position);

        h.tvName.setText(wg.name + " (" + wg.id + ")");
        h.tvDesc.setText(wg.description);

        int count = FakeDataStore.getMemberCount(wg.id);
        User admin = FakeDataStore.getUserById(wg.adminUserId);

        h.tvMeta.setText("Mitglieder: " + count + " • Admin: " + (admin != null ? admin.displayName : wg.adminUserId));
        h.btnRequest.setOnClickListener(v -> listener.onRequestJoin(wg));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc, tvMeta;
        Button btnRequest;

        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvWgName);
            tvDesc = itemView.findViewById(R.id.tvWgDesc);
            tvMeta = itemView.findViewById(R.id.tvWgMeta);
            btnRequest = itemView.findViewById(R.id.btnWgRequest);
        }
    }
}


