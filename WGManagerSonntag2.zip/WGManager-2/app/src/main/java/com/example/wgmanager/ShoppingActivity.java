package com.example.wgmanager;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ShoppingActivity extends AppCompatActivity {

    private ArrayAdapter<DataStore.ShoppingItem> adapter;
    private TextView tvTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);

        ListView listView = findViewById(R.id.listViewShopping);
        EditText etNewItem = findViewById(R.id.etNewItem);
        EditText etPrice = findViewById(R.id.etPrice);
        Button btnAdd = findViewById(R.id.btnAddItem);
        tvTotal = findViewById(R.id.tvTotal);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, DataStore.shoppingList);
        listView.setAdapter(adapter);

        updateTotal();

        // Add Item
        btnAdd.setOnClickListener(v -> {
            String item = etNewItem.getText().toString();
            String priceStr = etPrice.getText().toString();

            if (!item.isEmpty()) {
                double price = 0.0;
                if(!priceStr.isEmpty()) {
                    try { price = Double.parseDouble(priceStr); } catch (Exception e) {}
                }

                DataStore.shoppingList.add(new DataStore.ShoppingItem(item, price));
                adapter.notifyDataSetChanged();
                updateTotal();

                etNewItem.setText("");
                etPrice.setText("");
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            DataStore.shoppingList.remove(position);
            adapter.notifyDataSetChanged();
            updateTotal();
        });
    }

    private void updateTotal() {
        double sum = 0;
        for(DataStore.ShoppingItem i : DataStore.shoppingList) {
            sum += i.price;
        }
        tvTotal.setText("Total Expenses: " + String.format("%.2f", sum) + "€");
    }
}