package com.example.wgmanager;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WGCrewActivity extends AppCompatActivity implements CrewAdapter.Listener {

    private RecyclerView rv;
    private CrewAdapter adapter;
    private User me;

    private Button btnRequests;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wg_crew);

        rv = findViewById(R.id.rvCrew);
        btnRequests = findViewById(R.id.btnRequests);

        me = SessionManager.getCurrentUser();
        if (me == null || !me.hasWg()) {
            finish();
            return;
        }

        // ✅ Admin-only: Requests Button
        btnRequests.setVisibility(me.isAdminLike() ? View.VISIBLE : View.GONE);
        btnRequests.setOnClickListener(v ->
                startActivity(new Intent(this, WGRequestsActivity.class))
        );

        adapter = new CrewAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        reload();
    }

    private void reload() {
        List<User> members = FakeDataStore.getWgMembers(me.wgId);
        adapter.submit(members, me);
    }

    @Override
    public void onKick(User user) {
        if (me == null || !me.isAdminLike()) return;

        // Admin kann sich selbst nicht kicken
        if (me.id.equals(user.id)) {
            Toast.makeText(this, "Du kannst dich nicht selbst kicken.", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Mitglied kicken?")
                .setMessage("Willst du " + user.displayName + " aus der WG entfernen?")
                .setPositiveButton("Ja, kicken", (d, w) -> {
                    FakeDataStore.kickMember(me.wgId, user.id);
                    Toast.makeText(this, "Mitglied entfernt", Toast.LENGTH_SHORT).show();
                    reload();
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }
}


