package com.example.wgmanager;

public class JoinRequest {
    public String id;
    public String wgId;
    public String requesterUserId;
    public long createdAt;
    public String status; // "PENDING", "APPROVED", "REJECTED"

    public JoinRequest(String id, String wgId, String requesterUserId) {
        this.id = id;
        this.wgId = wgId;
        this.requesterUserId = requesterUserId;
        this.createdAt = System.currentTimeMillis();
        this.status = "PENDING";
    }
}

