package com.example.wgmanager;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class WeekUtils {

    // ISO-ähnlicher WeekKey (für Demo ausreichend): "YYYY-Www"
    public static String getCurrentWeekKey() {
        Calendar cal = Calendar.getInstance(Locale.getDefault());
        return weekKeyFromCalendar(cal);
    }

    public static String addWeeks(String weekKey, int deltaWeeks) {
        Calendar cal = calendarFromWeekKey(weekKey);
        cal.add(Calendar.WEEK_OF_YEAR, deltaWeeks);
        return weekKeyFromCalendar(cal);
    }

    private static String weekKeyFromCalendar(Calendar cal) {
        int year = cal.get(Calendar.YEAR);
        int week = cal.get(Calendar.WEEK_OF_YEAR);
        return String.format(Locale.US, "%04d-W%02d", year, week);
    }

    private static Calendar calendarFromWeekKey(String weekKey) {
        // weekKey: "2026-W05"
        String[] parts = weekKey.split("-W");
        int year = Integer.parseInt(parts[0]);
        int week = Integer.parseInt(parts[1]);

        Calendar cal = new GregorianCalendar(Locale.getDefault());
        cal.clear();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.WEEK_OF_YEAR, week);
        // Setze auf Montag dieser Woche (ungefähr)
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return cal;
    }
}