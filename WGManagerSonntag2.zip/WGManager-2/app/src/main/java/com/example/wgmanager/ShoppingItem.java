package com.example.wgmanager;

public class ShoppingItem {
    public String id;
    public String wgId;
    public String name;
    public long createdAt;

    public ShoppingItem(String id, String wgId, String name) {
        this.id = id;
        this.wgId = wgId;
        this.name = name;
        this.createdAt = System.currentTimeMillis();
    }
}
