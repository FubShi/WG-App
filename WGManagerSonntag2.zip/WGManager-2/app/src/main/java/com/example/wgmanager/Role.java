package com.example.wgmanager;

public enum Role {
    USER,
    ADMIN,
    SUPER_ADMIN
}