package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPass = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        // Komfort-Funktion: Daten vor-ausfüllen zum schnellen Testen
        etEmail.setText("admin@wg.de");
        etPass.setText("123456");

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String pwd = etPass.getText().toString().trim();

            if (email.isEmpty() || pwd.isEmpty()) {
                Toast.makeText(this, "Bitte alle Felder ausfüllen", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isAdmin = false;

            // Logik: Hardcodierter Login-Check
            if (email.equals("admin@wg.de") && pwd.equals("123456")) {
                isAdmin = true; // Admin Modus aktivieren
                Toast.makeText(this, "Willkommen, Chef!", Toast.LENGTH_SHORT).show();
                startDashboard(isAdmin);
            }
            else if (email.equals("user@wg.de") && pwd.equals("123456")) {
                isAdmin = false; // User Modus aktivieren
                Toast.makeText(this, "Willkommen zuhause!", Toast.LENGTH_SHORT).show();
                startDashboard(isAdmin);
            }
            else {
                Toast.makeText(this, "Falsche Daten! (Tipp: admin@wg.de / 123456)", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startDashboard(boolean isAdmin) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("IS_ADMIN", isAdmin); // Rolle an den nächsten Screen weitergeben
        startActivity(intent);
        finish(); // Login-Screen schließen
    }
}
