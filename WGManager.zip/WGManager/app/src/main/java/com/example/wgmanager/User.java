package com.example.wgmanager;

public class User {
    private String name;
    private String role; // Rolle: "ADMIN" oder "USER"
    private int strikes; // Anzahl der Verwarnungen

    public User(String name, String role, int strikes) {
        this.name = name;
        this.role = role;
        this.strikes = strikes;
    }

    public String getName() { return name; }
    public String getRole() { return role; }
    public int getStrikes() { return strikes; }
}
