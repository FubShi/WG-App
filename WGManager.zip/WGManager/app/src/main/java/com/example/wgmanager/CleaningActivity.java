package com.example.wgmanager;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CleaningActivity extends AppCompatActivity {

    private boolean isAdmin;
    private List<Task> taskList = new ArrayList<>();
    private TaskAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaning);

        isAdmin = getIntent().getBooleanExtra("IS_ADMIN", false);

        // Dummy-Daten erstellen
        taskList.add(new Task("Küche putzen"));
        taskList.add(new Task("Müll rausbringen"));
        taskList.add(new Task("Bad wischen"));

        RecyclerView rv = findViewById(R.id.rvTasks);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter();
        rv.setAdapter(adapter);

        EditText etNew = findViewById(R.id.etNew);
        Button btnAdd = findViewById(R.id.btnAdd);

        btnAdd.setOnClickListener(v -> {
            String text = etNew.getText().toString().trim();
            if (!text.isEmpty()) {
                taskList.add(new Task(text));
                adapter.notifyDataSetChanged();
                etNew.setText("");
            }
        });
    }

    // Innerer Adapter für die Liste
    class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

        @NonNull
        @Override
        public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
            return new TaskViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
            Task task = taskList.get(position);
            holder.tvName.setText(task.getText());
            holder.cbDone.setOnCheckedChangeListener(null);
            holder.cbDone.setChecked(task.isDone());

            // --- ADMIN FEATURE: Conditional UI ---
            // Nur Admins sehen den Mülleimer
            if (isAdmin) {
                holder.btnDelete.setVisibility(View.VISIBLE);

                holder.btnDelete.setOnClickListener(v -> {
                    taskList.remove(position);
                    notifyDataSetChanged();
                    Toast.makeText(CleaningActivity.this, "Gelöscht!", Toast.LENGTH_SHORT).show();
                });

                // Langer Klick für Strike
                holder.itemView.setOnLongClickListener(v -> {
                    new AlertDialog.Builder(CleaningActivity.this)
                            .setTitle("Strafe verteilen")
                            .setMessage("Soll ein Strike vergeben werden?")
                            .setPositiveButton("Ja", (d, w) ->
                                    Toast.makeText(CleaningActivity.this, "Strike vergeben!", Toast.LENGTH_SHORT).show())
                            .setNegativeButton("Nein", null)
                            .show();
                    return true;
                });
            } else {
                holder.btnDelete.setVisibility(View.GONE);
            }

            holder.cbDone.setOnCheckedChangeListener((buttonView, isChecked) ->
                    task.setDone(isChecked)
            );
        }

        @Override
        public int getItemCount() {
            return taskList.size();
        }

        class TaskViewHolder extends RecyclerView.ViewHolder {
            TextView tvName; CheckBox cbDone; ImageButton btnDelete;
            public TaskViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvTask);
                cbDone = itemView.findViewById(R.id.cbDone);
                btnDelete = itemView.findViewById(R.id.btnDelete);
            }
        }
    }
}