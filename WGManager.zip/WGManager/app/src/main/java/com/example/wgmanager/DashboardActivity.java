package com.example.wgmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private boolean isAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Admin-Status empfangen
        isAdmin = getIntent().getBooleanExtra("IS_ADMIN", false);

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        TextView tvWallOfShame = findViewById(R.id.tvWallOfShame);

        if (isAdmin) {
            tvWelcome.setText("Hallo Chef! \uD83D\uDC51");
        } else {
            tvWelcome.setText("Moin Bewohner! \uD83D\uDC4B");
        }

        // Simulierte Daten für die Wall of Shame
        String fakeData = "🔥Samed (3 Strikes)\n" +
                "• Yves (1 Strike)\n" +
                "• Holger (0 Strikes)";
        tvWallOfShame.setText(fakeData);

        // Buttons mit Navigation verknüpfen
        setupNavButton(R.id.btnPutz, CleaningActivity.class);
        setupNavButton(R.id.btnShop, ShoppingActivity.class);
        setupNavButton(R.id.btnCrew, CrewActivity.class);
    }

    private void setupNavButton(int buttonId, Class<?> targetActivity) {
        Button btn = findViewById(buttonId);
        btn.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, targetActivity);
            intent.putExtra("IS_ADMIN", isAdmin); // Rolle weitergeben
            startActivity(intent);
        });
    }
}