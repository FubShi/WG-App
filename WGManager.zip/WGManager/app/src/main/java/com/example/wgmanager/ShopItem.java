package com.example.wgmanager;

public class ShopItem {
    private String name;
    private boolean bought;

    public ShopItem(String name) {
        this.name = name;
        this.bought = false;
    }

    public String getName() { return name; }
    public boolean isBought() { return bought; }
    public void setBought(boolean bought) { this.bought = bought; }
}