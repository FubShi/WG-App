package com.example.wgmanager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class CrewActivity extends AppCompatActivity {

    private boolean isAdmin;
    private List<User> userList = new ArrayList<>();
    private CrewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crew);

        isAdmin = getIntent().getBooleanExtra("IS_ADMIN", false);

        // Dummy User
        userList.add(new User("Samed", "ADMIN", 3));
        userList.add(new User("Yves", "USER", 1));
        userList.add(new User("Holger", "USER", 0));

        RecyclerView rv = findViewById(R.id.rvCrew);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CrewAdapter();
        rv.setAdapter(adapter);
    }

    class CrewAdapter extends RecyclerView.Adapter<CrewAdapter.CrewViewHolder> {
        @NonNull
        @Override
        public CrewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_crew, parent, false);
            return new CrewViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull CrewViewHolder holder, int position) {
            User user = userList.get(position);
            holder.tvName.setText(user.getName());
            holder.tvRole.setText(user.getRole());

            // Bilder laden (Glide)
            String url = "[https://ui-avatars.com/api/?name=](https://ui-avatars.com/api/?name=)" + user.getName() + "&background=random";
            Glide.with(CrewActivity.this).load(url).circleCrop().into(holder.imgAvatar);

            // Admin Kick-Funktion
            if (isAdmin && !"ADMIN".equals(user.getRole())) {
                holder.btnKick.setVisibility(View.VISIBLE);
                holder.btnKick.setOnClickListener(v ->
                        Toast.makeText(CrewActivity.this, "Bewohner gekickt!", Toast.LENGTH_SHORT).show()
                );
            } else {
                holder.btnKick.setVisibility(View.GONE);
            }
        }

        @Override
        public int getItemCount() {
            return userList.size();
        }

        class CrewViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvRole; ImageView imgAvatar; Button btnKick;
            public CrewViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvCrewName);
                tvRole = itemView.findViewById(R.id.tvCrewRole);
                imgAvatar = itemView.findViewById(R.id.imgAvatar);
                btnKick = itemView.findViewById(R.id.btnKick);
            }
        }
    }
}
