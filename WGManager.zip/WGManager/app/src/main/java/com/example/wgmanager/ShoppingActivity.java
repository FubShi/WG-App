package com.example.wgmanager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ShoppingActivity extends AppCompatActivity {

    private List<ShopItem> itemList = new ArrayList<>();
    private ShopAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);

        // Dummy Daten
        itemList.add(new ShopItem("Milch"));
        itemList.add(new ShopItem("Klopapier"));
        itemList.add(new ShopItem("Nudeln"));

        RecyclerView rv = findViewById(R.id.rvShop);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ShopAdapter();
        rv.setAdapter(adapter);

        EditText etNew = findViewById(R.id.etShopItem);
        Button btnAdd = findViewById(R.id.btnAddShop);

        btnAdd.setOnClickListener(v -> {
            String name = etNew.getText().toString().trim();
            if (!name.isEmpty()) {
                itemList.add(new ShopItem(name));
                adapter.notifyDataSetChanged();
                etNew.setText("");
            }
        });
    }

    class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopViewHolder> {
        @NonNull
        @Override
        public ShopViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
            return new ShopViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ShopViewHolder holder, int position) {
            ShopItem item = itemList.get(position);
            holder.tvName.setText(item.getName());
            holder.cbDone.setOnCheckedChangeListener(null);
            holder.cbDone.setChecked(item.isBought());

            holder.btnDelete.setVisibility(View.GONE); // Nie löschen Button anzeigen

            holder.cbDone.setOnCheckedChangeListener((v, c) -> item.setBought(c));
        }

        @Override
        public int getItemCount() { return itemList.size(); }

        class ShopViewHolder extends RecyclerView.ViewHolder {
            TextView tvName; CheckBox cbDone; View btnDelete;
            public ShopViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvTask);
                cbDone = itemView.findViewById(R.id.cbDone);
                btnDelete = itemView.findViewById(R.id.btnDelete);
            }
        }
    }
}
